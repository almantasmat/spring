export class Building {
	id: string;
	name: string;
	address: string;
	index: string;
	sectorCode: string;
	energyUnits: number;
	energyUnitMax: number;
}
